/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { z } from 'zod';
import { runAgent, AgentContext, AgentMessage } from './agent/index';
import { runAudit, suggestCodes } from './agent/audit-engine';
import type { Material, PurchaseOrder, WarehouseEntry } from './src/types';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Request validation schemas
const MessageSchema = z.object({
  role: z.enum(['user', 'assistant']),
  content: z.string(),
});

const ChatRequestSchema = z.object({
  messages: z.array(MessageSchema).min(1),
  sheetsContext: z.object({
    isOfficialSheetsConnected: z.boolean().optional().default(false),
    userProfile: z.object({
      name: z.string().optional().default('Rossy'),
      email: z.string().optional().default('compraarza@gmail.com'),
    }).optional().default({ name: 'Rossy', email: 'compraarza@gmail.com' }),
    active_materials_catalog: z.array(z.any()).optional().default([]),
    active_purchase_orders: z.array(z.any()).optional().default([]),
    warehouse_entries: z.array(z.any()).optional().default([]),
  }),
});

function normalizeContext(raw: z.infer<typeof ChatRequestSchema>['sheetsContext']): AgentContext {
  return {
    isOfficialSheetsConnected: raw.isOfficialSheetsConnected,
    userProfile: {
      name: raw.userProfile.name || 'Rossy',
      email: raw.userProfile.email || 'compraarza@gmail.com',
    },
    materials: (raw.active_materials_catalog || []).map(m => ({
      code: String(m.code || ''),
      description: String(m.description || ''),
      unit: String(m.unit || 'PZ'),
      price: Number(m.price) || 0,
    })),
    orders: (raw.active_purchase_orders || []).map(o => ({
      id: String(o.id || ''),
      project: String(o.project || ''),
      code: String(o.code || ''),
      description: String(o.description || ''),
      unit: String(o.unit || 'PZ'),
      quantity: Number(o.quantity) || 0,
      price: Number(o.price) || 0,
      receivedQuantity: Number(o.receivedQuantity) || 0,
      status: ['pendiente', 'parcial', 'completado'].includes(o.status) ? o.status : 'pendiente',
      supplier: String(o.supplier || ''),
      total: Number(o.total) || 0,
    })),
    warehouse: (raw.warehouse_entries || []).map(w => ({
      id: String(w.id || ''),
      orderId: String(w.orderId || ''),
      code: String(w.code || w.materialCode || ''),
      description: String(w.description || w.materialName || ''),
      expectedQuantity: Number(w.expectedQuantity) || 0,
      receivedQuantity: Number(w.receivedQuantity) || 0,
      status: ['completo', 'discrepancia'].includes(w.status) ? w.status : 'completo',
      observer: String(w.observer || w.receivedBy || 'Kari'),
    })),
  };
}

// API endpoint for Rossy's conversational assistant
app.post('/api/gemini/chat', async (req, res) => {
  const requestId = `req-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  const startTime = Date.now();

  try {
    const parseResult = ChatRequestSchema.safeParse(req.body);
    if (!parseResult.success) {
      console.warn(`[${requestId}] Invalid request body:`, parseResult.error.flatten());
      return res.status(400).json({ error: 'Invalid request body', details: parseResult.error.flatten() });
    }

    const { messages, sheetsContext } = parseResult.data;
    const context = normalizeContext(sheetsContext);

    const result = await runAgent(messages as AgentMessage[], context, {
      apiKey: process.env.GEMINI_API_KEY,
      model: process.env.GEMINI_MODEL || 'gemini-2.5-pro',
    });

    console.log(`[${requestId}] Agent response in ${Date.now() - startTime}ms`, {
      model: result.metadata.model,
      fallback: result.metadata.fallback,
      hasAction: result.response.action !== null,
    });

    return res.json(result.response);
  } catch (err: any) {
    console.error(`[${requestId}] Gemini route error:`, err);
    return res.status(500).json({
      content: 'Lo siento Rossy, tuve un problema técnico procesando tu mensaje. ¿Podemos intentarlo de nuevo?',
      action: null,
    });
  }
});

// Health check endpoint
app.get('/api/health', (_req, res) => {
  const hasKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');
  res.json({ status: 'ok', agentMode: hasKey ? 'live' : 'demo' });
});

// Audit endpoints
app.post('/api/audit', async (req, res) => {
  try {
    const { materials, orders, warehouse } = req.body as {
      materials: Material[];
      orders: PurchaseOrder[];
      warehouse: WarehouseEntry[];
    };
    if (!Array.isArray(materials) || !Array.isArray(orders)) {
      res.status(400).json({ error: 'materials and orders arrays are required' });
      return;
    }
    const result = await runAudit({ materials, orders, warehouse: warehouse || [] });
    res.json(result);
  } catch (err) {
    console.error('Audit error:', err);
    res.status(500).json({ error: err instanceof Error ? err.message : 'Audit failed' });
  }
});

app.post('/api/audit/suggest-codes', async (req, res) => {
  try {
    const { materials } = req.body as { materials: Material[] };
    if (!Array.isArray(materials)) {
      res.status(400).json({ error: 'materials array is required' });
      return;
    }
    const result = await suggestCodes(materials);
    res.json(result);
  } catch (err) {
    console.error('Suggest codes error:', err);
    res.status(500).json({ error: err instanceof Error ? err.message : 'Suggestion failed' });
  }
});

// Export audit report to a new auxiliary Google Sheet (never touches source sheets)
app.post('/api/audit/export-to-sheets', async (req, res) => {
  try {
    const { accessToken, title, issues, duplicates, suggestions } = req.body as {
      accessToken: string;
      title?: string;
      issues: any[];
      duplicates?: any[];
      suggestions?: any[];
    };

    if (!accessToken) {
      res.status(400).json({ error: 'accessToken is required' });
      return;
    }

    const sheetTitle = title || `Auditoría Arza - ${new Date().toLocaleDateString('es-MX')}`;

    const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        properties: { title: sheetTitle },
        sheets: [
          { properties: { title: 'Hallazgos' } },
          { properties: { title: 'Duplicados' } },
          { properties: { title: 'Sugerencias' } },
        ],
      }),
    });

    if (!createRes.ok) {
      const err = await createRes.text();
      console.error('Error creating audit sheet:', err);
      res.status(502).json({ error: 'Could not create Google Sheet', detail: err });
      return;
    }

    const sheet = await createRes.json();
    const spreadsheetId = sheet.spreadsheetId;

    const issueRows = (issues || []).map((i) => [
      i.severity,
      i.type,
      i.title,
      i.description,
      i.impact,
      i.suggestedAction,
      i.data?.orderId || '',
      i.data?.materialCode || '',
      i.data?.project || '',
      i.data?.supplier || '',
      i.data?.expected ?? '',
      i.data?.actual ?? '',
    ]);

    const duplicateRows = (duplicates || []).flatMap((g) =>
      g.items.map((item: any) => [g.canonicalDescription, g.suggestedCode, item.code, item.description, item.occurrences])
    );

    const suggestionRows = (suggestions || []).map((s) => [
      s.materialDescription,
      s.currentCode || '',
      s.suggestedCode,
      s.suggestedPrice,
      s.confidence,
      s.reason,
    ]);

    const batch = {
      valueInputOption: 'RAW',
      data: [
        {
          range: 'Hallazgos!A1',
          values: [
            ['Severidad', 'Tipo', 'Título', 'Descripción', 'Impacto MXN', 'Acción sugerida', 'Orden', 'Código', 'Proyecto', 'Proveedor', 'Esperado', 'Actual'],
            ...issueRows,
          ],
        },
        {
          range: 'Duplicados!A1',
          values: [
            ['Descripción canónica', 'Código sugerido', 'Código duplicado', 'Descripción duplicada', 'Ocurrencias'],
            ...duplicateRows,
          ],
        },
        {
          range: 'Sugerencias!A1',
          values: [
            ['Descripción', 'Código actual', 'Código sugerido', 'Precio sugerido', 'Confianza', 'Razón'],
            ...suggestionRows,
          ],
        },
      ],
    };

    const writeRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchUpdate`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify(batch),
      }
    );

    if (!writeRes.ok) {
      const err = await writeRes.text();
      console.error('Error writing audit sheet:', err);
      res.status(502).json({ error: 'Sheet created but could not write data', detail: err });
      return;
    }

    res.json({
      spreadsheetId,
      url: `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`,
      title: sheetTitle,
    });
  } catch (err) {
    console.error('Export to sheets error:', err);
    res.status(500).json({ error: err instanceof Error ? err.message : 'Export failed' });
  }
});

// Configure Vite middleware in development or static serving inside production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Arza Google Sheets Agent server running on http://0.0.0.0:${PORT}`);
    console.log(`Agent mode: ${process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY' ? 'LIVE (Gemini)' : 'DEMO (local)'}`);
  });
}

startServer();
